//
//  ViewController.swift
//  AutoLYOUTS
//
//  Created by Guru Ketepalle on 29/11/18.
//  Copyright © 2018 Guru Ketepalle. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

